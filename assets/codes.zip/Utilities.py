import numpy as np
from graphviz import Graph
import itertools

class Vertex(object):
    def __init__(self, id):
        self.id = id
        self.neighbours = []

    def get_id(self):
        return self.id
    def get_neighbours(self):
        return self.neighbours
    def add_neighbour(self, neighbour):
        for existing_neighbour in self.neighbours:
            if existing_neighbour == neighbour:
                return
        self.neighbours.append(neighbour)

def graphGenerator(numOfVtx, maxDeg, seed):
    graph = []
    edgeList = []

    minDeg = 1
    maxDeg = maxDeg + 1 # addition 1 to account for exclusivity in random.radint function

    lowVtxDiff = -2 
    upperVtxDiff = 2 

    # seeding
    np.random.seed(seed)
    for vertex in range(numOfVtx):
        # add the new vertex
        graph.append(Vertex(vertex))
        degree = maxDeg
        for i in range(degree):
            lowVtx = vertex + lowVtxDiff
            if lowVtx < 0:
                lowVtx = 0
            highVtx = vertex + upperVtxDiff
            if highVtx > numOfVtx:
                highVtx = numOfVtx
            neighbour = np.random.randint(lowVtx, highVtx)
            if neighbour not in graph[vertex].get_neighbours() and neighbour != vertex:
                graph[vertex].add_neighbour(neighbour)
                if (neighbour, vertex) not in edgeList:
                    edgeList.append((vertex, neighbour))
     
    # corrections in adjacency list
    for vertex in graph:
        for neighbour in vertex.get_neighbours():
            if vertex.id not in graph[neighbour].get_neighbours():
                graph[neighbour].add_neighbour(vertex.id)
    return graph, edgeList

def plotGraph(graph, edgeList, graphNum):
    G = Graph()
    # adding nodes
    for vtx in graph:
        G.node(str(vtx.id), str(vtx.id))
    # adding edges
    for vtx1, vtx2 in edgeList:
        G.edge(str(vtx1), str(vtx2), constraint='true')

    graphName = 'graph' + str(graphNum) + '.gv'
    G.render(graphName, view=True)

# DO NOT MODIFY THIS CLASS
class UnionFind():
    def __init__(self, nodes):
        """
        Union-Find data structure initialization sets each node to be its own
        parent (so that each node is in its own set/connected component), and
        to also have rank 0.

        Input
        -----
        - nodes: list of nodes
        """
        self.parents = {}
        self.ranks = {}

        for node in nodes:
            self.parents[node] = node
            self.ranks[node] = 0

    def find(self, node):
        """
        Finds which set/connected component that a node belongs to by returning
        the root node within that set.

        Technical remark: The code here implements path compression.

        Input
        -----
        - node: the node that we want to figure out which set/connected
            component it belongs to

        Output
        ------
        the root node for the set/connected component that `node` is in
        """
        if self.parents[node] != node:
            # path compression
            self.parents[node] = self.find(self.parents[node])
        return self.parents[node]

    def union(self, node1, node2):
        """
        Merges the connected components of two nodes.

        Inputs
        ------
        - node1: first node
        - node2: second node
        """
        root1 = self.find(node1)
        root2 = self.find(node2)
        if root1 != root2:  # only merge if the connected components differ
            if self.ranks[root1] > self.ranks[root2]:
                self.parents[root2] = root1
            else:
                self.parents[root1] = root2
                if self.ranks[root1] == self.ranks[root2]:
                    self.ranks[root2] += 1
