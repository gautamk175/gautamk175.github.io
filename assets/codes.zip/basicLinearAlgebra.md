                                  Morsel 2:

Expected test time: 25 minutes

Numerical Algorithm Specification are:
To find:
	W: vector of length = NUM_OF_FEATURES
Given:
	Y: vector of length = NUM_OF_OBS
	X: Tensor (of order 2) of shape = NUM_OF_OBS * NUM_OF_FEATURES

Constants:
<!-- typical numbers -->
NUM_OF_FEATURES = 10
NUM_OF_OBS = 500

Outline the approach (write anything that pops up in your mind you feel/believe is the right direction towards problem solution) to solve for W, given
	XW = Y
, where XW is the matrix product of X and W. 

Hint: X is not invertible, haha!! On top of it, number of equations are more than number of unknowns, lol!!
