                                        Instructions

- Be honest:
	no one will closely monitor you, so write in detail everywhere you have had the help of google, even the search phrase.

- Use helper functions and classes in Utilities.py:
	yup, you read that correctly, helper functions are there to help, take their help!

- Proceed in the following order of morsels/parts:
	1) basic data structures and algorithms
	2) basic linear algebra 
	3) advance data structures and algorithms
	4) advance linear algebra
	
	- Note that the level shoots up the roof very quickly, but hey! no need to panic, engage your mind in verbose mode and write whatever you feel is useful towards the problem solution.

	- Expected timing constraint for individual parts/morsels is given within, but nonetheless measure the time you took for each morsel and report it (and be honest!).

	- You can take 10-20 minutes break b/w any two test morsels.
