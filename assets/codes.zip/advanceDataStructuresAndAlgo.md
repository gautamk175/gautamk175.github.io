                            Morsel 3:

Expected test time: 100 minutes

Preferred programming language is Python (to alleviate data-structure requirements):

1) Full implementation of Kruskal's MST algorithm, Source: kruskal_algo.png (hint: use UnionFind data structure in Utilities.py file)

Note: 
1) Generate random edge weights.
2) Use helper Vertex class and graphGenerator, plotGraph functions provided in Utilities.py file.
