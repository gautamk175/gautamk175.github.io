                                        Morsel 4:

Expected test time: 100 minutes

Numerical Algorithm Specifications are:
To find:
	W: vector of length = NUM_OF_FEATURES
Given:
	Y: vector of length = NUM_OF_OBS
	X: Tensor (of order 2) of shape = NUM_OF_OBS * NUM_OF_FEATURES

Constants:
<!-- typical numbers -->
NUM_OF_FEATURES = 10
NUM_OF_OBS = 500

Instead of going for one-step solution (in basicLinearAlgebra problem) to determine w, outline the implementation (then finally implement) of following algorithm. Source: gradientDescent.png

But before delving in the depths of ocean of numeric methods, tell us:
1) E_in is a scalar, what are the dimension/s and length of inv_delta of E_in ?
2) W and X_n are vectors of length NUM_OF_FEATURES, what about dimensions of W_T * X_n ?

BTW, I would suggest against skipping above questions before attempting to implement the algorithm. Pay close attention to avoid tensor dimension confusion!!

Clarifications in gradientDescent.png:
	- N stands for NUM_OF_OBS
	- X_n is a row entry from the full tensor X (guess the dimensions and length of X_n!)

Furthermore tell us:
1) What do you suggest to terminate the algorithm?
2) Suggest value for eta (constant used in the W update step)?
