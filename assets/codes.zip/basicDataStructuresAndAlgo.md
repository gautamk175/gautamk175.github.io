                                   Morsel 1:

Expected test time: 35 minutes

1) Outline (psuedo-code and step-by-step example) how bfs algorithm can be used to trace shortest path b/w any 2 points in a graph.
2) Psuedo-code for an algorithm to extract induced sub-graph from a sub-set of given graph vertices.
3) Outline an algorithm to bisect a graph using bfs abstraction (Hint: Tricky one).
