import os, sys



cmd = 'g++ --std=c++11 main.cpp -o main -lflann'
os.system(cmd) # returns the exit status

# row = [numOfTrainingDP, numOfFeatures, DESIRED_NEIGHS, distanceMetrics]

cmd = './main > out'
os.system(cmd) # returns the exit status
print 'Graph construction completes'