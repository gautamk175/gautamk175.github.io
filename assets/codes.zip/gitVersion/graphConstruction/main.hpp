// #include <flann/flann.h>
#include "../flann/flann.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <cmath>
#include <algorithm>
#include <iostream>
#include <fstream>
#include <vector>
#include <numeric>

using namespace std;

char const *stepDone = "====================================================================";
int DESIRED_NEIGHS = 0;
string distanceMetrics = "";
int numOfObs = 0;
int numOfFeatures = 0;
int numOfNeigh = DESIRED_NEIGHS;

struct flannInfo
{
	flann::Matrix<float> *dataset;
    vector<float> targets;
	int noOfKDTrees;
	int numOfChecks;
	int numOfNeigh;
};

// graph data structures
struct neighNode
{
    int id;
    float edgeWeight;

    neighNode(int in_id) : id(in_id) {}

    neighNode(int in_id, float in_edgeWeight) : id(in_id), edgeWeight(in_edgeWeight) {}

    bool operator==(const neighNode &o) const { return id == o.id; }

    bool operator<(const neighNode &o) const { return id < o.id; }

};

struct node
{
    int id;
    float clas;

    node(int in_id, float in_clas) : id(in_id), clas(in_clas){}
    vector <struct neighNode> neighList;
};

struct graph
{
    int numOfVts;

    graph(int in_numOfVts) : numOfVts(in_numOfVts) {}

    vector<struct node> vtx;
    vector<signed char> attribute;
    vector<vector<int>> hash;

    vector<int> potCritical;
};

struct clubbedGraph
{
    struct graph *graph;
    vector<float> cost;
};

struct edgeNode
{
    int vertex_1, vertex_2;
    float weight;

    edgeNode(int in_vtx_1, int in_vtx_2, float in_weight) : vertex_1(in_vtx_1), vertex_2(in_vtx_2), weight(in_weight) {}

    bool operator<(const edgeNode &e) const { return weight > e.weight; }
};

int64_t s_clock ()
{
    struct timeval tv;
    gettimeofday (&tv, NULL);

    return (int64_t) (tv.tv_sec * 1000 + tv.tv_usec / 1000);
}

void parser() {
    const char *filename = "input.csv";
    FILE *fp;
    char ch;

    fp = fopen(filename, "r");
    int i = 0, row = 1, num;
    char line[4098];
    while (fgets(line, 4098, fp) && (i < row))
    {
        int j = 0;
        const char* tok;
        for (tok = strtok(line, ","); tok && *tok; j++, tok = strtok(NULL, ",\n")) {
            if (j == 0)
                numOfObs = atoi(tok);
            else if (j == 1)
                numOfFeatures = atoi(tok);
            else if (j == 2)
                DESIRED_NEIGHS = atoi(tok);
            else if (j ==3){
                distanceMetrics = tok;
                distanceMetrics = distanceMetrics.substr(0, distanceMetrics.size()-1);
            }
        }
    }
}

// Reading data
void read_csv(int row, int col, char const *filename, flann::Matrix<float> dataset, vector<float> &targets) {
    FILE *file;


    file = fopen(filename, "r");

    int numOfClas0Obs = 0;

    int i = 0;
    char line[col * 25];
    while (fgets(line, col*25, file) && (i < row))
    {
        char* tmp = strdup(line);

        int j = 0;
        const char* tok;
        for (tok = strtok(line, ","); tok && *tok; j++, tok = strtok(NULL, ",\n"))
        {
            if (j < col - 1){
                dataset[i][j] = atof(tok);
            }
            else{
                targets.push_back((float) atof(tok));
            }
        }
        free(tmp);
        i++;
    }

    int glb_idx;
}

void write_results(const char* filename, flann::Matrix<int> data, int rows, int cols)
{
    FILE* fout;
    int i,j;

    fout = fopen(filename,"w");
    if (!fout) {
        printf("Cannot open output file.\n");
        exit(1);
    }
    
    for (i=0;i<rows;++i) {
        for (j=0;j<cols;++j) {
            fprintf(fout,"%d ", data[i][j]);
        }
        fprintf(fout,"\n");
    }
    fclose(fout);
}

// Writing input graph label to file
void printGraph(graph *graph) {
    // cout <<"wtf in graph printing "<<endl;
    int i, j;
    ofstream labelfile, input_graph;

    input_graph.open("input_graph");
    vector<struct neighNode>::iterator aNeighbour;
    for (i = 0; i < graph->vtx.size(); ++i)
    {       
        for (aNeighbour = graph->vtx[i].neighList.begin(); aNeighbour < graph->vtx[i].neighList.end(); ++aNeighbour){
            // printf("%d\t%d\t%f\n",graph->vtx[i].id, aNeighbour->id, aNeighbour->edgeWeight);
            input_graph<<graph->vtx[i].id<<"\t"<<aNeighbour->id<<"\t"<<aNeighbour->edgeWeight<<endl;
        }
    }

    input_graph.close();
    // Write label in file
    labelfile.open("seeds");

    for (i = 0; i < graph->vtx.size(); ++i)
    { 
        if (graph->vtx[i].clas != -1){
            labelfile <<graph->vtx[i].id << "\t" << graph->vtx[i].clas<<"\t"<<1.0<<endl;
            // printf("%d\t%f\n", graph->vtx[i].id, graph->vtx[i].clas);
        }
    }
    labelfile.close();
}

struct graph * graphConstruction(struct flannInfo *flannInfo,flann::Matrix<float> baseDists, flann::Matrix<int> baseIndices){

    
    vector<bool> neigh_list_finish(flannInfo->dataset->rows, false);
    vector<int> no_tot_neigh(flannInfo->dataset->rows, 0);
    vector<int> no_same_clas_neigh(flannInfo->dataset->rows, 0);
    vector<int> node_neighs(flannInfo->dataset->rows, 0);

    // ==========================================Graph-Init-Part-1===========================================
    // num of graph vertices is the num of rows in indices matrix
    graph *graph = new struct graph(baseIndices.rows);
    graph->attribute.resize(graph->numOfVts, 0);
    graph->hash.resize(graph->numOfVts);

    int numOfInitNeigh = (baseIndices.cols - 1);

    int i, j;
    float edgeWeight, nodeWeight, exponent;
    for (i = 0; i < graph->numOfVts; ++i)
    {
        struct node newNode(i, flannInfo->targets[i]);
        for (j = 1; j < numOfInitNeigh + 1; ++j) {
                edgeWeight = baseDists[i][j];
                struct neighNode newNeigh(baseIndices[i][j], edgeWeight);
                newNode.neighList.push_back(newNeigh);

                no_tot_neigh[i]++;
            }
        graph->vtx.push_back(newNode);
    }
    delete baseIndices.ptr();
    delete baseDists.ptr();

    return graph;
}



struct graph* myFlann(struct flannInfo *flannInfo) {

    // ==========================================STATIC-DATA-STRUCTURES======================================
    // vector<bool> neigh_list_finish(flannInfo->dataset->rows, false);
    vector<float> reach(flannInfo->dataset->rows, 0.0);
    vector<int> no_tot_neigh(flannInfo->dataset->rows, 0);
    vector<int> no_same_clas_neigh(flannInfo->dataset->rows, 0);
    vector<int> node_neighs(flannInfo->dataset->rows, 0);

    // ==============================================Base-Case===============================================
    flann::Matrix<int> baseIndices(new int[flannInfo->dataset->rows*flannInfo->numOfNeigh], flannInfo->dataset->rows, flannInfo->numOfNeigh);
    flann::Matrix<float> baseDists(new float[flannInfo->dataset->rows*flannInfo->numOfNeigh], flannInfo->dataset->rows, flannInfo->numOfNeigh);
    
    // different metrics 
    if (distanceMetrics.compare("L2") == 0){
        flann::Index<flann::L2<float>> baseIndex(*(flannInfo->dataset), flann::KDTreeIndexParams(flannInfo->noOfKDTrees));
        baseIndex.buildIndex();
        baseIndex.knnSearch(*(flannInfo->dataset), baseIndices, baseDists, flannInfo->numOfNeigh, flann::SearchParams(flannInfo->numOfChecks));
        return graphConstruction(flannInfo, baseDists, baseIndices);
    }
    
    else if (distanceMetrics.compare("L2_Simple") == 0){
        flann::Index<flann::L2_Simple<float>> baseIndex(*(flannInfo->dataset), flann::KDTreeIndexParams(flannInfo->noOfKDTrees));
        baseIndex.buildIndex();
        baseIndex.knnSearch(*(flannInfo->dataset), baseIndices, baseDists, flannInfo->numOfNeigh, flann::SearchParams(flannInfo->numOfChecks));
        return graphConstruction(flannInfo, baseDists, baseIndices);
    }
    
    else if (distanceMetrics.compare("L2_3D") == 0){
        flann::Index<flann::L2_3D<float>> baseIndex(*(flannInfo->dataset), flann::KDTreeIndexParams(flannInfo->noOfKDTrees));
        baseIndex.buildIndex();
        baseIndex.knnSearch(*(flannInfo->dataset), baseIndices, baseDists, flannInfo->numOfNeigh, flann::SearchParams(flannInfo->numOfChecks));
        return graphConstruction(flannInfo, baseDists, baseIndices);
    }
    
    else if (distanceMetrics.compare("CS") == 0){
        flann::Index<flann::CS<float>> baseIndex(*(flannInfo->dataset), flann::LinearIndexParams());
        baseIndex.buildIndex();
        baseIndex.knnSearch(*(flannInfo->dataset), baseIndices, baseDists, flannInfo->numOfNeigh, flann::SearchParams(flannInfo->numOfChecks));
        return graphConstruction(flannInfo, baseDists, baseIndices);

    }

    else if (distanceMetrics.compare("ISC") == 0){
        flann::Index<flann::ISC<float>> baseIndex(*(flannInfo->dataset), flann::LinearIndexParams());
        baseIndex.buildIndex();
        baseIndex.knnSearch(*(flannInfo->dataset), baseIndices, baseDists, flannInfo->numOfNeigh, flann::SearchParams(flannInfo->numOfChecks));
        return graphConstruction(flannInfo, baseDists, baseIndices);
    }
    
    else if (distanceMetrics.compare("L1") == 0){
        flann::Index<flann::L1<float>> baseIndex(*(flannInfo->dataset), flann::KDTreeIndexParams(flannInfo->noOfKDTrees));
        baseIndex.buildIndex();
        baseIndex.knnSearch(*(flannInfo->dataset), baseIndices, baseDists, flannInfo->numOfNeigh, flann::SearchParams(flannInfo->numOfChecks));
        return graphConstruction(flannInfo, baseDists, baseIndices);
    }

    // else if (distanceMetrics.compare("MinkowskiDistance") == 0){
    //     flann::setDistanceType(FLANN_DIST_MINKOWSKI , 3);
    //     flann::Index<flann::MinkowskiDistance<float>> baseIndex(*(flannInfo->dataset), flann::KDTreeIndexParams(flannInfo->noOfKDTrees));
    //     baseIndex.buildIndex();
    //     baseIndex.knnSearch(*(flannInfo->dataset), baseIndices, baseDists, flannInfo->numOfNeigh, flann::SearchParams(flannInfo->numOfChecks));
    //     return graphConstruction(flannInfo, baseDists, baseIndices);
    // }

    else if (distanceMetrics.compare("MaxDistance") == 0){
        flann::Index<flann::MaxDistance<float>> baseIndex(*(flannInfo->dataset), flann::LinearIndexParams());
        baseIndex.buildIndex();
        baseIndex.knnSearch(*(flannInfo->dataset), baseIndices, baseDists, flannInfo->numOfNeigh, flann::SearchParams(flannInfo->numOfChecks));
        return graphConstruction(flannInfo, baseDists, baseIndices);
    }
    
    // else if (distanceMetrics.compare("HammingPopcnt") == 0){
    //     flann::Index<flann::HammingPopcnt<float>> baseIndex(*(flannInfo->dataset), flann::LinearIndexParams());
    //     baseIndex.buildIndex();
    //     baseIndex.knnSearch(*(flannInfo->dataset), baseIndices, baseDists, flannInfo->numOfNeigh, flann::SearchParams(flannInfo->numOfChecks));
    //     return graphConstruction(flannInfo, baseDists, baseIndices);
    // }
    
    // else if (distanceMetrics.compare("Hamming") == 0){
    //     flann::Index<flann::Hamming<float>> baseIndex(*(flannInfo->dataset), flann::LinearIndexParams());
    //     baseIndex.buildIndex();
    //     baseIndex.knnSearch(*(flannInfo->dataset), baseIndices, baseDists, flannInfo->numOfNeigh, flann::SearchParams(flannInfo->numOfChecks));
    //     return graphConstruction(flannInfo, baseDists, baseIndices);
    // }
    
    else if (distanceMetrics.compare("HistIntersectionDistance") == 0){
        flann::Index<flann::HistIntersectionDistance<float>> baseIndex(*(flannInfo->dataset), flann::KDTreeIndexParams(flannInfo->noOfKDTrees));
        baseIndex.buildIndex();
        baseIndex.knnSearch(*(flannInfo->dataset), baseIndices, baseDists, flannInfo->numOfNeigh, flann::SearchParams(flannInfo->numOfChecks));
        return graphConstruction(flannInfo, baseDists, baseIndices);
    }
    
    else if (distanceMetrics.compare("HellingerDistance") == 0){
        flann::Index<flann::HellingerDistance<float>> baseIndex(*(flannInfo->dataset), flann::KDTreeIndexParams(flannInfo->noOfKDTrees));
        baseIndex.buildIndex();
        baseIndex.knnSearch(*(flannInfo->dataset), baseIndices, baseDists, flannInfo->numOfNeigh, flann::SearchParams(flannInfo->numOfChecks));
        return graphConstruction(flannInfo, baseDists, baseIndices);
    }
    
    else if (distanceMetrics.compare("ChiSquareDistance") == 0){
        flann::Index<flann::ChiSquareDistance<float>> baseIndex(*(flannInfo->dataset), flann::KDTreeIndexParams(flannInfo->noOfKDTrees));
        baseIndex.buildIndex();
        baseIndex.knnSearch(*(flannInfo->dataset), baseIndices, baseDists, flannInfo->numOfNeigh, flann::SearchParams(flannInfo->numOfChecks));
        return graphConstruction(flannInfo, baseDists, baseIndices);
    }
    
    else if (distanceMetrics.compare("KL_Divergence") == 0){
        flann::Index<flann::KL_Divergence<float>> baseIndex(*(flannInfo->dataset), flann::KDTreeIndexParams(flannInfo->noOfKDTrees));
        baseIndex.buildIndex();
        baseIndex.knnSearch(*(flannInfo->dataset), baseIndices, baseDists, flannInfo->numOfNeigh, flann::SearchParams(flannInfo->numOfChecks));
        return graphConstruction(flannInfo, baseDists, baseIndices);
    }

    delete baseIndices.ptr();
    delete baseDists.ptr();
    // return graph;
}

void printGraphPos(graph *graph, flann::Matrix<float> dataset) {
    int i;
    vector<struct node>::iterator aNode;
    vector<struct neighNode>::iterator aNeighbour;
    for (aNode = graph->vtx.begin(); aNode < graph->vtx.end(); ++aNode)
        if (graph->attribute[aNode->id] >= 1)
            printf("For vtx: %d, (%f, %f)\n", aNode->id, dataset[aNode->id][0], dataset[aNode->id][1]);
}

struct graph* graphComplete(struct graph* graph) {

    // ==========================================Part-2===========================================    
    vector<struct node>::iterator aNode;
    vector<struct neighNode>::iterator aNeighbour, found;
    for (aNode = graph->vtx.begin(); aNode < graph->vtx.end(); ++aNode)
        for (aNeighbour = aNode->neighList.begin(); aNeighbour < aNode->neighList.end(); ++aNeighbour)
        {
            found = find(graph->vtx[aNeighbour->id].neighList.begin(), graph->vtx[aNeighbour->id].neighList.end(), neighNode(aNode->id));
            if (found == graph->vtx[aNeighbour->id].neighList.end()) {
                struct neighNode newNeigh(aNode->id, aNeighbour->edgeWeight);
                graph->vtx[aNeighbour->id].neighList.push_back(newNeigh);
            }
        }

    return graph;
}

struct graph* graph_stats(struct graph* graph) {

    vector<float>::iterator stDev;
    vector<struct node>::iterator aNode;
    vector<struct neighNode>::iterator aNeighbour;
    vector<float> no_of_neigh_List;
    int numOfNeigh_node_i = 0;
    int count_desiredNeigh = 0;
    float avgNumOfNeigh_node_i;
    float standardDeviation = 0;
    bool critical;

    for (aNode = graph->vtx.begin(); aNode < graph->vtx.end(); ++aNode) {
        critical = false;
        numOfNeigh_node_i += (aNode->neighList.end()-aNode->neighList.begin());
        no_of_neigh_List.push_back(aNode->neighList.end()-aNode->neighList.begin());
        
        if (DESIRED_NEIGHS == aNode->neighList.end()-aNode->neighList.begin())
            count_desiredNeigh ++;
    }

    avgNumOfNeigh_node_i  = numOfNeigh_node_i/float(graph->vtx.end()-graph->vtx.begin());
    for (stDev = no_of_neigh_List.begin(); stDev < no_of_neigh_List.end(); ++stDev){
        standardDeviation += pow((*stDev - avgNumOfNeigh_node_i),2);
    }
    standardDeviation = standardDeviation/float(graph->vtx.end()-graph->vtx.begin());

    cout <<"AverageDegree : "<<avgNumOfNeigh_node_i<<", standardDeviation : "<<standardDeviation<<", nodesWithDesiredNeighs : "<<count_desiredNeigh<<endl;

    printGraph(graph);

    return graph;
}

void runHeuristic(struct graph *graph) {

    graph = graph_stats (graph);
    cout << stepDone << endl;
}