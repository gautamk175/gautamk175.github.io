#include "main.hpp"

int main(int argc, char** argv)
{
    parser();

    flann::Matrix<float> dataset(new float[numOfObs*numOfFeatures], numOfObs, numOfFeatures);
    vector<float> targets;
    read_csv(numOfObs, numOfFeatures + 1 , "data.csv", dataset, targets);
    struct flannInfo *flannBaseInfo = new struct flannInfo;
    flannBaseInfo->numOfNeigh = DESIRED_NEIGHS;

    flannBaseInfo->numOfChecks = 70;
    flannBaseInfo->noOfKDTrees = 25;

    // data-structures
    flannBaseInfo->dataset = &dataset;
    flannBaseInfo->targets = targets;
    
    int64_t annCompTime = s_clock();
    struct graph *graph = myFlann(flannBaseInfo);

    annCompTime = s_clock() - annCompTime;
    int64_t graphCompleteCompTime = s_clock();
    graph = graphComplete(graph);
    graphCompleteCompTime = s_clock() - graphCompleteCompTime;

    runHeuristic(graph);

    delete[] dataset.ptr();
    delete flannBaseInfo;

    return 0;
}