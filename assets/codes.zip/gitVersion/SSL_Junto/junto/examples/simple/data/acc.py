import numpy as np

def readFile(filename, mode = 1):
	if mode == 1:
		with open(filename,'r') as file:
			for row in file:
				values = row.split('\t')
				if "true" not in values:
					if values[3].split(' ')[0] == '__DUMMY__':
						prediction = int(values[3].split(' ')[2])
						predictDict[int(values[0])] = prediction
					else:
						prediction = int(values[3].split(' ')[0])
						predictDict[int(values[0])] = prediction
						predictWithDummy[int(values[0])] = prediction
	elif mode == 2:
		with open(filename,'r') as file:
			for row in file:
				values = row.split('\t')
				trueDict[int(values[0])] = int(float(values[1]))


def accuracy(predictionDict):
	totalCount = 0
	trueCount = 0
	for key in predictionDict:
		if predictionDict[key] == trueDict[key]:
			trueCount += 1
		totalCount += 1

	accuracy = trueCount/float(totalCount)
	return accuracy


predictDict = {}
predictWithDummy = {}
trueDict = {}

filename = "label_prop_output"
readFile(filename)

filename = "total_seeds"
readFile(filename, mode = 2)


# ======================= ACCURACY MEASUREMENT =======================
# acc = accuracy(predictWithDummy)
# print 'Accuracy with considering dummies are : ',acc
acc = accuracy(predictDict)
print 'Accuracy without dummies are : ',acc
