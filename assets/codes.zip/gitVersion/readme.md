This package/repository has following part 
	- Weighted graph construction
	- Label propagation

---------------- Weighted graph construction ----------------
For weighted graph construction we have used "FLANN" package with additional implementation of following distance metric : 
	- CS (cosine similarity)
	- ISC (improved sqrt cosine similarity)
	Compile code - "g++ --std=c++11 main.cpp -o main" for running it
	and "./main" for executing it
	It takes follwing as input : 
		1. "data.csv" - A csv file where each row is data point and column is corresponding feature. The last value of column should be target value and "-1" if it is not unknown.
			Example : 	0,1,2,4,1
						1,4,3,2,0
						1,5,5,1,-1
					In the above example there are 3 datapoints with 4 features in which label of 1 and 2 are known and third one is unknown.
		2. input.csv - CSV should have follwing input in order : [numOfTrainingDP, numOfFeatures, DESIRED_NEIGHS, distanceMetrics]
			numOfTrainingDP : Totaal number of datapoint 
			numOfFeatures : Number of features in data.csv
			DESIRED_NEIGHS : Number of approximate neighbors for each datapoints.
			distanceMetrics : Distance metrics to be used for neighbor search and graph construction. 
				- Apart from FLANN metrics you can use "CS" for cosine similarity, "ISC" for improved sqrt cosine similarity.
				- CS and ISC are found to perform better on text data [https://www.gstech.xyz/projects/gb_ssl ]
	Incase you do not want to use this implemented version, add below code segment to "/usr/local/include/flann/algorithms/dist.h" to use similarity metrics "CS" and "ISC" for graph construction.
	<!-- --------------------------------------------------------------- -->
	// Cosine similarity
	template<class T>
	struct CS
	{
	    typedef T ElementType;
	    typedef typename Accumulator<T>::Type ResultType;
	    template <typename Iterator1, typename Iterator2>
	    ResultType operator()(Iterator1 a, Iterator2 b, size_t size, ResultType worst_dist = -1) const
	    {
	        ResultType result = ResultType();
	        ResultType sum_A, sum_B, product;
	        Iterator1 last = a + size;
	        while (a < last) {
	            product = product + (*a) * (*b);
	            sum_A = sum_A + (*a) * (*a);
	            sum_B = sum_B + (*b) * (*b);
	            a += 1;
	            b += 1;
	        }
	        sum_A = sqrt(sum_A);
	        sum_B = sqrt(sum_B);       
	        result = product/(sum_A*sum_B);
	        return acos(result);
	    }
	};
	// Improved sqrt cosine similarity
	template<class T>
	struct ISC
	{
	    // typedef bool is_vector_space_distance;
	    typedef T ElementType;
	    typedef typename Accumulator<T>::Type ResultType;
	    template <typename Iterator1, typename Iterator2>
	    ResultType operator()(Iterator1 a, Iterator2 b, size_t size, ResultType worst_dist = -1) const
	    {
	        ResultType result = ResultType();
	        ResultType sum_A, sum_B, product;
	        Iterator1 last = a + size;
	        while (a < last) {
	            product = product + sqrt((*a) * (*b));
	            sum_A = sum_A + (*a);
	            sum_B = sum_B + (*b);
	            a += 1;
	            b += 1;
	        }
	        // product = sqrt(product);
	        sum_A = sqrt(sum_A);
	        sum_B = sqrt(sum_B);       
	        result = product/(sum_A*sum_B);
	        return acos(result);
	    }
	};
	<!-- --------------------------------------------------------------- -->
	Once you have added it, call "ISC" and "CS" like the rest of distancec metrics in FLANN.
	ex : flann::Index<flann::CS<float>> baseIndex(*(flannInfo->dataset), flann::LinearIndexParams()); for cosine similarity
		ex : flann::Index<flann::ISC<float>> baseIndex(*(flannInfo->dataset), flann::LinearIndexParams()); for improved sqrt cosine similarity
			see "main.hpp" in "graphConstruction" for more info
The output is "input_graph" and "seeds" which is input to graph based SSL implemented using Junto toolkit. 

Execute Junto toolkit as "SSL_Junto/junto/bin/junto config SSL_Junto/simple_config" and paste the input graph and seeds in "data" folder of SSL_Junto.

Following point should be kept in mind :
	- Any edge weight should not be 0 in the input graph
	- "gold_label" can be provided as input to Junto. Gold label are the labels of which the implementor art completely sure to be correct.
	- The "seeds" has three column - 1. vertex_id, 2. vertexc_class 3. confidence of vertex to be in the given class
